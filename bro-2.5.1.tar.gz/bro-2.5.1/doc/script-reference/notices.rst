
.. Not nice but I don't find a way to link to the notice index
.. directly from the upper level TOC tree.

Notices
=======

See the `Bro Notice Index <../bro-noticeindex.html>`_.
